
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/product.dart';
import 'dart:async'; 
class ApiService {
  static const String baseUrl = 'https://api.escuelajs.co/api/v1';

  Future<List<Product>> fetchProducts() async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/products'))
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body) as List;
        return jsonData.map((p) => Product.fromJson(p)).toList();
      } else {
        throw Exception(
            'Failed to load products: ${response.statusCode}');
      }
    } on TimeoutException {
      throw Exception(
          'Request timeout. Check your internet connection.');
    } catch (e) {
      throw Exception('Error fetching products: $e');
    }
  }

  Future<Product> fetchProductDetail(String id) async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/products/$id'))
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        return Product.fromJson(jsonDecode(response.body));
      } else if (response.statusCode == 404) {
        throw Exception('Product not found');
      } else {
        throw Exception(
            'Failed to load product: ${response.statusCode}');
      }
    } on TimeoutException {
      throw Exception('Request timeout');
    } catch (e) {
      throw Exception('Error fetching product: $e');
    }
  }

  Future<List<Product>> searchProducts(String query) async {
    try {
      final products = await fetchProducts();
      return products
          .where((p) =>
              p.title.toLowerCase().contains(query.toLowerCase()) ||
              p.description.toLowerCase().contains(query.toLowerCase()))
          .toList();
    } catch (e) {
      throw Exception('Error searching products: $e');
    }
  }

  Future<List<String>> fetchCategories() async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/categories'))
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final List jsonData = jsonDecode(response.body);
        return jsonData
            .map((cat) => cat['name'].toString())
            .toList();
      } else {
        throw Exception('Failed to load categories');
      }
    } catch (e) {
      throw Exception('Error fetching categories: $e');
    }
  }

  Future<List<Product>> fetchProductsByCategory(
      String categoryId) async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/categories/$categoryId/products'))
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body) as List;
        return jsonData.map((p) => Product.fromJson(p)).toList();
      } else {
        throw Exception('Failed to load category products');
      }
    } catch (e) {
      throw Exception('Error fetching category products: $e');
    }
  }
}