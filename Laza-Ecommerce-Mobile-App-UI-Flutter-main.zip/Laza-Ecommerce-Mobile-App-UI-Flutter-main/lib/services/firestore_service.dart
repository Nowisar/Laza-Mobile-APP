
import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> addToCart(String userId, String productId, int quantity, double price, {String? title, String? image}) async {
    await _firestore
        .collection('carts')
        .doc(userId)
        .collection('items')
        .doc(productId)
        .set({
          'productId': productId,
          'quantity': quantity,
          'price': price,
          'title': title ?? 'Product',
          'image': image ?? '',
          'addedAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
  }

  Future<void> removeFromCart(String userId, String productId) async {
    await _firestore
        .collection('carts')
        .doc(userId)
        .collection('items')
        .doc(productId)
        .delete();
  }

  Future<void> updateCartQuantity(String userId, String productId, int quantity) async {
    await _firestore
        .collection('carts')
        .doc(userId)
        .collection('items')
        .doc(productId)
        .update({'quantity': quantity});
  }

  Future<void> clearCart(String userId) async {
    final items = await _firestore
        .collection('carts')
        .doc(userId)
        .collection('items')
        .get();
    for (var item in items.docs) {
      await item.reference.delete();
    }
  }

  Future<void> addToFavorites(String userId, String productId, Map<String, dynamic> productData) async {
    await _firestore
        .collection('favorites')
        .doc(userId)
        .collection('items')
        .doc(productId)
        .set({
          'productId': productId,
          ...productData,
          'addedAt': FieldValue.serverTimestamp(),
        });
  }

  Future<void> removeFromFavorites(String userId, String productId) async {
    await _firestore
        .collection('favorites')
        .doc(userId)
        .collection('items')
        .doc(productId)
        .delete();
  }

  Stream<QuerySnapshot> getCartItems(String userId) {
    return _firestore
        .collection('carts')
        .doc(userId)
        .collection('items')
        .snapshots();
  }

  Stream<QuerySnapshot> getFavorites(String userId) {
    return _firestore
        .collection('favorites')
        .doc(userId)
        .collection('items')
        .snapshots();
  }

  Future<bool> isInFavorites(String userId, String productId) async {
    final doc = await _firestore
        .collection('favorites')
        .doc(userId)
        .collection('items')
        .doc(productId)
        .get();
    return doc.exists;
  }
}