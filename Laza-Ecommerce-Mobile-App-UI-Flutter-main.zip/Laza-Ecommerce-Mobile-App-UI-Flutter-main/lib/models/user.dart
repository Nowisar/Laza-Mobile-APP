class User {
  final String uid;
  final String email;
  final String name;
  final String phone;
  final String address;
  final DateTime createdAt;

  User({
    required this.uid,
    required this.email,
    this.name = '',
    this.phone = '',
    this.address = '',
    required this.createdAt,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      uid: json['uid'],
      email: json['email'],
      name: json['name'] ?? '',
      phone: json['phone'] ?? '',
      address: json['address'] ?? '',
      createdAt: json['createdAt'] is String
          ? DateTime.parse(json['createdAt'])
          : json['createdAt']?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'uid': uid,
      'email': email,
      'name': name,
      'phone': phone,
      'address': address,
      'createdAt': createdAt,
    };
  }
}
