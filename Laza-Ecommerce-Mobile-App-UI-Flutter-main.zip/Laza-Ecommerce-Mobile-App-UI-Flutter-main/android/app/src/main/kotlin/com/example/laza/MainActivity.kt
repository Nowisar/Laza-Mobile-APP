package com.laza.laza

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
