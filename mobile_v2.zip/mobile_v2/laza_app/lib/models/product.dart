
class Product {
  final int id;
  final String title;
  final double price;
  final String description;
  final List<String> images;
  final Category? category;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Product({
    required this.id,
    required this.title,
    required this.price,
    required this.description,
    required this.images,
    this.category,
    this.createdAt,
    this.updatedAt,
  });

  String get imageUrl => images.isNotEmpty
      ? images[0]
      : 'https://via.placeholder.com/300x300?text=No+Image';

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'] ?? 0,
      title: json['title'] ?? 'Unknown Product',
      price: (json['price'] ?? 0).toDouble(),
      description: json['description'] ?? '',
      images: _parseImages(json['images']),
      category: json['category'] != null
          ? Category.fromJson(json['category'])
          : null,
      createdAt: json['createdAt'] != null
          ? DateTime.parse(json['createdAt'])
          : null,
      updatedAt: json['updatedAt'] != null
          ? DateTime.parse(json['updatedAt'])
          : null,
    );
  }

  static List<String> _parseImages(dynamic images) {
    if (images == null) return [];
    
    if (images is List) {
      return images
          .map((img) {
            if (img is String) {
              return img;
            } else if (img is Map && img.containsKey('url')) {
              return img['url'].toString();
            }
            return null;
          })
          .whereType<String>()
          .toList();
    }
    return [];
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'price': price,
      'description': description,
      'images': images,
      'category': category?.toJson(),
      'createdAt': createdAt?.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
    };
  }

  Map<String, dynamic> toFirestoreMap() {
    return {
      'productId': id.toString(),
      'title': title,
      'price': price,
      'image': imageUrl,
      'description': description,
    };
  }
}

class Category {
  final int id;
  final String name;
  final String image;

  Category({
    required this.id,
    required this.name,
    required this.image,
  });

  factory Category.fromJson(Map<String, dynamic> json) {
    return Category(
      id: json['id'] ?? 0,
      name: json['name'] ?? 'Unknown',
      image: json['image'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'image': image,
    };
  }
}