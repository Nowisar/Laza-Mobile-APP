import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/cart_provider.dart';


class CheckoutScreen extends StatelessWidget {
  const CheckoutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Checkout')),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.shopping_cart, size: 80, color: Colors.green),
              SizedBox(height: 20),
              Text(
                'Order Summary',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              Text(
                'Total: \$${context.watch<CartProvider>().total.toStringAsFixed(2)}',
                style: TextStyle(fontSize: 18),
              ),
              SizedBox(height: 40),
              ElevatedButton(
                onPressed: () => _confirmCheckout(context),
                child: Text('Confirm Order'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _confirmCheckout(BuildContext context) async {
  await context.read<CartProvider>().checkout();

  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) => AlertDialog(
      title: const Text('Success!'),
      content: const Text('Your order has been placed.'),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(dialogContext).pop(); 
            Navigator.of(context).popUntil((route) => route.isFirst);
          },
          child: const Text('Done'),
        ),
      ],
    ),
  );
  }}