
import 'package:flutter/material.dart';
import '../services/firestore_service.dart';
import 'dart:async';

class FavoritesProvider extends ChangeNotifier {
  final FirestoreService _firestoreService = FirestoreService();
  List<Map<String, dynamic>> _favorites = [];
  String? _userId;

  List<Map<String, dynamic>> get favorites => _favorites;

  void setUserId(String userId) {
  if (_userId == userId) return;
  _userId = userId;
  loadFavorites(); 
}


  Future<void> addToFavorites(String productId, Map<String, dynamic> productData) async {
    if (_userId == null) return;
    await _firestoreService.addToFavorites(_userId!, productId, productData);
    await loadFavorites();
  }

  Future<void> removeFromFavorites(String productId) async {
    if (_userId == null) return;
    await _firestoreService.removeFromFavorites(_userId!, productId);
    await loadFavorites();
  }

StreamSubscription? _favSub;
 

Future<void> loadFavorites() async {
  if (_userId == null) return;

  _favSub?.cancel(); 

  _favSub = _firestoreService.getFavorites(_userId!).listen((snapshot) {
    _favorites = snapshot.docs
        .map((doc) => doc.data() as Map<String, dynamic>)
        .toList();
    notifyListeners();
  });
}

@override
void dispose() {
  _favSub?.cancel();
  super.dispose();
}
void clearLocal() {
  _favorites = [];
  _userId = null;
  notifyListeners();
}


  Future<bool> isFavorite(String productId) async {
    if (_userId == null) return false;
    return await _firestoreService.isInFavorites(_userId!, productId);
  }
}