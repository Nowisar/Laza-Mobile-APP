
import 'dart:async';
import 'package:flutter/material.dart';
import '../models/cart_item.dart';
import '../services/firestore_service.dart';

class CartProvider extends ChangeNotifier {
  final FirestoreService _firestoreService = FirestoreService();
  List<CartItem> _items = [];
  String? _userId;
  StreamSubscription? _cartSub;

  List<CartItem> get items => List.unmodifiable(_items);

  double get total => _items.fold(0.0, (sum, item) => sum + item.totalPrice);

  void setUserId(String userId) {
    if (_userId == userId) return;
    _userId = userId;
    _subscribeToCart();
  }
void clearLocal() {
  _items.clear();
  _userId = null;
  notifyListeners();
}
  void _subscribeToCart() {
    _cartSub?.cancel();
    if (_userId == null) return;
    _cartSub = _firestoreService.getCartItems(_userId!).listen(
      (snapshot) {
        _items = snapshot.docs.map((doc) {
          final data = doc.data() as Map<String, dynamic>;
          return CartItem.fromJson({
            ...data,
            'productId': data['productId'] ?? doc.id,
          });
        }).toList();
        notifyListeners();
      },
      onError: (err) {
        debugPrint('Cart listen error: $err');
      },
    );
  }

  Future<void> addToCart(String productId, String title, double price, String image) async {
    if (_userId == null) return;
    try {
      await _firestoreService.addToCart(
        _userId!,
        productId,
        1,
        price,
        title: title,
        image: image,
      );
    } catch (e) {
      debugPrint('addToCart failed: $e');
      rethrow;
    }
  }

  Future<void> deleteItem(String productId) async {
    if (_userId == null) return;
    await _firestoreService.removeFromCart(_userId!, productId);
  }

  Future<void> updateQuantity(String productId, int quantity) async {
    if (_userId == null) return;
    if (quantity <= 0) {
      await deleteItem(productId);
    } else {
      await _firestoreService.updateCartQuantity(_userId!, productId, quantity);
    }
  }

  Future<void> checkout() async {
    if (_userId == null) return;
    await _firestoreService.clearCart(_userId!);
  }

  @override
  void dispose() {
    _cartSub?.cancel();
    super.dispose();
  }
}